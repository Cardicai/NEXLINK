
import NexLinkApp from '@/components/NexLinkApp'

export default function Page() {
  return <NexLinkApp />
}
